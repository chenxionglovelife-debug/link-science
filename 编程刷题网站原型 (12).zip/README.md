
  # 编程刷题网站原型

  This is a code bundle for 编程刷题网站原型. The original project is available at https://www.figma.com/design/tOkxsEo8Cf2qPjSgCMWrCr/%E7%BC%96%E7%A8%8B%E5%88%B7%E9%A2%98%E7%BD%91%E7%AB%99%E5%8E%9F%E5%9E%8B.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  